import React, { useState, useRef } from "react";
import Image from "next/image";
import back from "@/assets/shared/icon-arrow-left.svg";
import editFeedback from "@/assets/shared/icon-edit-feedback.svg";
import DropDown from "@/components/DropDown";
import down from "@/assets/shared/icon-arrow-down.svg";
import { CloseIcon } from "next/dist/client/components/react-dev-overlay/internal/icons/CloseIcon";
import DropDownField from "@/components/fields/DropDownField";
import InputField from "@/components/fields/InputFeild";
import InputFieldTextArea from "@/components/fields/InputFieldTextArea";
import CustomButton from "@/components/Buttons";

const Edit = () => {
  const category = [
    "Feature",
    "UI",
    "Suggestion",
    "Planned",
    "In-Progress",
    "Live",
  ];
  const status = ["Suggestion ", "Planned", "In-Progress", "Live"];

  return (
    <section className="flex flex-col bg-gray-100 h-full items-center">
      <nav className="mt-8 mb-4 flex flex-row items-center 0 w-full max-w-3xl">
        <Image className={"ml-8 md:ml-32 "} src={back} alt="Go Back" />
        <small className="ml-4 font-bold text-slate-500">Go Back</small>
      </nav>
      <div className="m-8 p-4 flex flex-col rounded-md bg-white md:min-w-[400px] md:w-[500px]">
        <Image className={"-mt-8"} src={editFeedback} alt="edit feedback" />
        <h3 className="text-[#3A4374] mt-8 font-bold text-md">
          Editing 'Add a dark theme option'
        </h3>
        <InputField
          title={"Feedback Title"}
          subTitle={"Add a short, descriptive headline"}
        />
        <DropDownField
          title="Category"
          subTitle="Choose a category for your feedback"
          options={category}
        />
        <DropDownField
          title="Update Status"
          subTitle="Change feature status"
          options={status}
        />

        <InputFieldTextArea
          title={"Feedback Detail"}
          subTitle={
            "Include any specific comments on what should be improved, added, etc"
          }
        />
        <footer
          className={"flex flex-col-reverse md:flex-row md:justify-between "}
        >
          <CustomButton value={"Delete"} className="bg-[#D73737] mt-2" />
          <div className={"flex flex-col-reverse md:flex-row"}>
            <CustomButton
              value={"Cancel"}
              className="bg-[#3A4374] md:mx-4 mt-2 "
            />
            <CustomButton
              value={"Save Changes"}
              className="bg-[#AD1FEA] mt-2 "
            />
          </div>
        </footer>
      </div>
    </section>
  );
};

export default Edit;
