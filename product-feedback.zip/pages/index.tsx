import { Inter } from "next/font/google";
import Header from "@/components/header";
import Sugegestions from "@/components/sugegestions";
import Roadmap from "@/components/roadmap";
import Categories from "@/components/categories";
import Card from "@/components/gradient";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  return (
    <main
      className={
        "p-5 bg-gray-100 md:flex md:flex-col md:items-center lg:flex lg:flex-row h-screen w-screen lg:justify-center lg:items-start"
      }
    >
      <section className={"m-8 hidden md:flex md:flex-row lg:flex lg:flex-col"}>
        {/*side content*/}
        <Card />
        <Categories selectedCategory={"All"} />
        <Roadmap />
      </section>
      <section className={"flex flex-col"}>
        {/*main content*/}
        <Header />
        <Sugegestions />
      </section>
    </main>
  );
}
