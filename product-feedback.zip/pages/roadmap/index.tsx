import RoadMapHeader from "@/components/header/roadMapHeader";
import HorizontalNavigation from "@/components/navigation";

const RoadMap = () => {
  return (
    <section>
      <RoadMapHeader />
      <HorizontalNavigation />
    </section>
  );
};
export default RoadMap;
