import back from "@/assets/shared/icon-arrow-left-white.svg";
import Image from "next/image";
import CustomButton from "@/components/Buttons";

const RoadMapHeader = () => {
  return (
    <header
      className={"p-3 bg-[#373F68] flex flex-row items-center justify-between "}
    >
      <div className={"ml-2"}>
        <div className={"flex flex-row "}>
          <Image
            className={"object-contain "}
            src={back}
            alt={"go back"}
            width={7}
            height={7}
          />
          <p className={"text-white text-xs font-bold ml-3"}>Go Back</p>
        </div>
        <h4 className={"text-white font-bold tracking-tighter mt-2"}>
          RoadMap
        </h4>
      </div>

      <CustomButton
        value={"+  Add feedback"}
        className={"bg-[#AD1FEA] -space-x-1.5 tracking-tight px-4 h-1/2"}
      />
    </header>
  );
};
export default RoadMapHeader;
