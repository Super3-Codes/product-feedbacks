import suggestion from "@/assets/suggestions/icon-suggestions.svg";
import DropDown from "@/components/DropDown";
import Image from "next/image";
import React, { useState } from "react";

export default function Header() {
  const dropdownItems = [
    "Most Upvotes",
    "Least Upvotes",
    "Most Comments",
    "Least Comments",
  ];
  const [selectedItem, setSelectedItem] = useState<string>("Most Upvotes");
  const [isOpen, setIsOpen] = useState(false);
  const handleSelect = (item: string) => {
    setSelectedItem(item);
    setIsOpen(!isOpen);
  };

  function toggleDropdown() {
    setIsOpen(!isOpen);
  }

  const onClicked = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();
    //redirect to pages
  };
  return (
    <div
      className={
        "p-8 my-5 flex w-screen md:w-[700px] flex-row justify-between items-center md:rounded-lg bg-[#373f68] h-[44px]"
      }
    >
      <div className={"flex flex-row items-center text-gray-50"}>
        <Image
          className={"hidden md:flex"}
          src={suggestion}
          alt={"hint"}
          height={20}
          width={25}
        />
        <h4 className={"text-18 font-bold mx-4 hidden md:flex"}>Suggestions</h4>
        <small>Sort by :</small>
        <DropDown
          isOpen={isOpen}
          toggleDropdown={toggleDropdown}
          items={dropdownItems}
          selectedItem={selectedItem}
          handleSelect={handleSelect}
        />
        <p className={"mx-2 cursor-pointer"} onClick={toggleDropdown}>
          {selectedItem}
        </p>
      </div>
      <button
        className={
          "bg-[#ad1fea] font-bold mx-4 px-4 py-2  hover:bg-[#c75af6] rounded-lg text-gray-50"
        }
      >
        + Add Feedback
      </button>
    </div>
  );
}
