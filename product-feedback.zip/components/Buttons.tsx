import React from "react";

const CustomButton: React.FC<{
  value: string;
  className: string;
}> = ({ value, className }) => {
  return (
    <button
      className={`rounded-md p-2 font-bold text-sm  text-white ${className}`}
    >
      {value}
    </button>
  );
};

export default CustomButton;
