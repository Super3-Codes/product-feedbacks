import React from "react";

const InputField: React.FC<{
  title: string;
  subTitle: string;
}> = ({ title, subTitle }) => {
  return (
    <div className="mt-6 flex flex-col">
      <h4 className="text-[#3A4374] text-sm font-bold">{title}</h4>
      <p className=" text-slate-500 text-sm ">{subTitle}</p>
      <input
        className="bg-[#F7F8FD] text-[#3A4C8A] font-light text-sm appearance-none rounded-md mt-2 py-3.5 px-4 leading-tight focus:outline-none"
        type="text"
        value="Add a dark theme option"
      />
    </div>
  );
};
export default InputField;
