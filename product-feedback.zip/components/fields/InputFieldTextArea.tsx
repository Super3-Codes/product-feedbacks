import React from "react";

const InputFieldTextArea: React.FC<{
  title: string;
  subTitle: string;
}> = ({ title, subTitle }) => {
  return (
    <div className="mt-4 flex flex-col">
      <h4 className="text-[#3A4374] text-sm font-bold">{title}</h4>
      <p className="text-gray-500  text-sm ">{subTitle}</p>

      <textarea
        className="bg-[#F7F8FD] text-sm text-[#3A4C8A] font-light appearance-none rounded-md my-4 py-4 px-4 leading-tight focus:outline-none"
        value="it would help people with light sensitivities who prefer dark mode"
      />
    </div>
  );
};
export default InputFieldTextArea;
