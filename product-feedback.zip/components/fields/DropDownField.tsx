import Image from "next/image";
import down from "@/assets/shared/icon-arrow-down.svg";
import DropDown from "@/components/DropDown";
import React, { useState } from "react";

interface DropDownFieldProps {
  title: string;
  subTitle: string;
  options: string[];
}

const DropDownField: React.FC<{
  title: string;
  subTitle: string;
  options: string[];
}> = ({ title, subTitle, options }) => {
  const [selectedValue, setSelectedValue] = useState<string>("Feature");
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (item: string) => {
    setSelectedValue(item);
    setIsOpen(!isOpen);
  };

  function toggleDropdown() {
    setIsOpen(!isOpen);
  }

  return (
    <div className="mt-4 flex flex-col">
      <h4 className="text-[#3A4374] text-sm font-bold">{title}</h4>
      <p className="text-gray-500  text-sm ">{subTitle}</p>
      <div
        onClick={toggleDropdown}
        className="bg-[#F7F8FD] text-[#3A4C8A] text-sm mt-2 font-light py-3.5 px-4 flex flex-col justify-between"
      >
        <div className="flex flex-row justify-between">
          <p>{selectedValue}</p>
          <Image
            src={down}
            alt={"close"}
            width={20}
            height={20}
            className="scale-x-50 scale-y-50"
          />
        </div>
        <DropDown
          isOpen={isOpen}
          toggleDropdown={toggleDropdown}
          items={options}
          selectedItem={selectedValue}
          handleSelect={handleSelect}
        />
      </div>
    </div>
  );
};
export default DropDownField;
