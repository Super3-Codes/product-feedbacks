export default function Card() {
  return (
    <section
      className={
        "p-4 mb-8  flex flex-col justify-end w-[225px] bg-blue-300 h-28 rounded-md bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 ..."
      }
    >
      <h3 className={"text-white font-bold"}>Frontend Mentor</h3>
      <small className={"text-white font-small"}>Feedback board</small>
    </section>
  );
}
