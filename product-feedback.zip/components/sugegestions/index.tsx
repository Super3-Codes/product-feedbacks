import comment from "@/assets/shared/icon-comments.svg";
import Image from "next/image";

export default function Sugegestions() {
  return (
    <section
      className={
        "p-4 flex flex-row bg-white rounded-md items-center justify-between"
      }
    >
      <section className={"flex flex-row items-center"}>
        <div
          className={
            "my-2 p-1 flex bg-[#F2F4FF] mx-4 h-1/3 rounded-md justify-center items-center"
          }
        >
          112
        </div>

        <div className={"my-3"}>
          <h2 className={"font-bold text-[#3A4374]"}>
            Add tags for a solutions
          </h2>
          <p className={"text-slate-400"}>
            Easier to search for a solution based on a specific task
          </p>
          <div className={"my-2 p-1 inline-block bg-[#F2F4FF] rounded-lg"}>
            <p className={"mx-2 text-[#519CF1] font-semibold"}>Enhancement</p>
          </div>
        </div>
      </section>
      <div className={"flex flex-row"}>
        <Image
          className={"mx-4"}
          src={comment}
          alt={comment}
          width={25}
          height={20}
        />
        <p className={"font-semibold"}>2</p>
      </div>
    </section>
  );
}
