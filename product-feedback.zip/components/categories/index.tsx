import React from "react";

interface CategoriesProps {
  selectedCategory: string;
}

const Categories: React.FC<CategoriesProps> = ({ selectedCategory }) => {
  const categories = ["All", "UI", "UX", "Enhancement", "Feature", "Bug"];

  return (
    <section className="md:mx-4 lg:mx-0 flex flex-row flex-wrap w-[225px] bg-white mb-8 rounded-md p-2">
      {categories.map((category) => (
        <div
          key={category}
          className={`mx-1 my-1 cursor-pointer text-sm px-2 py-1 font-semibold rounded-lg ${
            category === selectedCategory
              ? "text-white bg-[#4661E6]"
              : "text-[#519CF1] bg-[#F2F4FF]"
          }`}
        >
          <p className="mx-2 text-sm">{category}</p>
        </div>
      ))}
    </section>
  );
};

export default Categories;
