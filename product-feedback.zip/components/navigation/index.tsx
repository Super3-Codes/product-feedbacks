const HorizontalNavigation = () => {
  return (
    <section>
      <ul className={"flex flex-row justify-between"}>
        <li className={"p-4 bg-green-50"}>Planned (2)</li>
        <li className={"p-4 bg-green-50"}>In-Progress (3)</li>
        <li className={"p-4 bg-green-50"}>Live</li>
      </ul>
    </section>
  );
};
export default HorizontalNavigation;
