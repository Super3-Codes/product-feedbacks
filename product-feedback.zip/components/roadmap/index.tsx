import Link from "next/link";

export default function Roadmap() {
  return (
    <section className={"p-4 flex flex-col rounded-md bg-white w-[225px]"}>
      <div className={"mx-2 flex flex-row justify-between"}>
        <h2 className={"text-[#3A4374] font-bold"}>Roadmap</h2>
        <Link className={"ml-2 text-[#519CF1] text-base underline"} href={""}>
          View
        </Link>
      </div>
      <ul>
        <li className={"mt-2 flex flex-row justify-between items-center"}>
          <div className={"flex flex-row items-center"}>
            <div className={"rounded-full bg-[#F49F85] h-2 w-2"}></div>
            <p className={"mx-3 font-light text-[#3a4374] text-sm"}>Planned</p>
          </div>
          <p className={"mr-2 text-base text-gray-500 font-semibold"}>2</p>
        </li>
        <li className={"mt-2 flex flex-row justify-between items-center"}>
          <div className={"flex flex-row items-center"}>
            <div className={"rounded-full bg-purple-500 h-2 w-2"}></div>
            <p className={"mx-3 font-light text-[#3a4374] text-sm"}>
              In-Progress
            </p>
          </div>
          <p className={"mr-2 text-base text-gray-500 font-semibold"}>3</p>
        </li>
        <li className={"mt-2 flex flex-row justify-between items-center"}>
          <div className={"flex flex-row items-center"}>
            <div className={"rounded-full bg-blue-400 h-2 w-2"}></div>
            <p className={"mx-3 font-light text-[#3a4374] text-sm"}>Live</p>
          </div>
          <p className={"mr-2 text-base text-gray-500 font-semibold"}>1</p>
        </li>
      </ul>
    </section>
  );
}
