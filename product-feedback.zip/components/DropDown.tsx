import React from "react";

interface DropDownProps {
  isOpen: boolean;
  toggleDropdown: () => void;
  items: string[];
  selectedItem: string;
  handleSelect: (item: string) => void;
}

const DropDown: React.FC<DropDownProps> = ({
  isOpen,
  toggleDropdown,
  items,
  selectedItem,
  handleSelect,
}) => {
  return (
    <div className="relative z-10">
      <ul
        className={`mt-10 bg-white rounded-lg text-gray-500 absolute min-w-[200px] left-0 w-full transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      >
        {items.map((item, index) => (
          <li
            key={index}
            className={`p-2 ${
              selectedItem === item ? "text-blue-500" : ""
            } cursor-pointer`}
            onClick={() => handleSelect(item)}
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DropDown;
